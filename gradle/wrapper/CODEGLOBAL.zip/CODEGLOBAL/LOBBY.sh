am start -n com.tencent.ig/com.epicgames.ue4.SplashActivity
cleanlog()
{
rm -rf /data/data/com.tencent.ig/app_appcache &> /dev/null
rm -rf /data/data/com.tencent.ig/app_bugly &> /dev/null
rm -rf /data/data/com.tencent.ig/cache &> /dev/null
rm -rf /data/data/com.tencent.ig/code_cache &> /dev/null
rm -rf /data/data/com.tencent.ig/app_crashrecord &> /dev/null
rm -rf /data/data/com.tencent.ig/files/iMSDK &> /dev/null
rm -rf /storage/emulated/0/osmini &> /dev/null
rm -rf /storage/emulated/0/tencent &> /dev/null
rm -rf /storage/emulated/0/MidasOversea &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/cache &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/tbslog &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo/RoleInfo.json &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Screenshots &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json &> /dev/null
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt &> /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt &> /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/iMSDK &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/ss_tmp &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/tss_tmp &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/AppEventsLogger.persistedevents &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/tpnlcache.data &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/tss_app_915c.dat &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/tss_cs_stat2.dat &> /dev/null 2>&1
rm -rf /data/data/com.tencent.ig/files/tss.i.m.dat &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/TencentUnipay.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/MidasOverseaIP.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/HSJsonData.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/gsdk_prefs.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/crashrecord.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/BuglySdkInfos.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/APMCfg.xml &> /dev/null 2>&1
rm -f /data/data/com.tencent.ig/shared_prefs/com.google.android.gms.appid.xml &> /dev/null 2>&1
rm -rf /storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/AntiCheat.ini &> /dev/null 2>&1
printf "Clear Cache & Log Done\n";
printf "🕒";
date
printf "\n";
}
sleep 2
PACKAGE='com.tencent.ig'
while [ $(pidof $PACKAGE) ]
do
cleanlog
if [ ! $(pidof $PACKAGE) ]; then
break
fi
sleep 20
done